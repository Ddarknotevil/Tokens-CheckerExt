Please If your using this Script don't forget to + rep me <3-------- https://cracked.io/Ddarknotevil

For more details about how the script works here https://github.com/Ddarknotevil/Tokens-CheckerExt
